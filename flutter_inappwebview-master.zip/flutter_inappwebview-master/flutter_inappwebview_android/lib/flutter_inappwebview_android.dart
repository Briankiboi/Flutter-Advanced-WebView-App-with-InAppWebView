library flutter_inappwebview_android;

export 'src/main.dart';
