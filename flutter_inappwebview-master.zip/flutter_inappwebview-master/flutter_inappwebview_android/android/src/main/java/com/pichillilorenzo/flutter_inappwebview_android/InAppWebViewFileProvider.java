package com.pichillilorenzo.flutter_inappwebview_android;

import androidx.core.content.FileProvider;

public class InAppWebViewFileProvider extends FileProvider {

  public static final String fileProviderAuthorityExtension = "flutter_inappwebview_android.fileprovider";

}
