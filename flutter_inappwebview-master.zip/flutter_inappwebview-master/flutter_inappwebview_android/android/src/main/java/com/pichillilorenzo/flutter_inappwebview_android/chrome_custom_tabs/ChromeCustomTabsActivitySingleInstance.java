package com.pichillilorenzo.flutter_inappwebview_android.chrome_custom_tabs;

public class ChromeCustomTabsActivitySingleInstance extends ChromeCustomTabsActivity {

  protected static final String LOG_TAG = "ChromeCustomTabsActivitySingleInstance";

}
