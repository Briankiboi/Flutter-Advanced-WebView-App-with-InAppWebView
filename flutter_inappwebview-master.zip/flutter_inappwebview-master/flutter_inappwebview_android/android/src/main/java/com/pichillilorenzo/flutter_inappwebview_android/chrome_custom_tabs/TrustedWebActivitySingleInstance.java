package com.pichillilorenzo.flutter_inappwebview_android.chrome_custom_tabs;

public class TrustedWebActivitySingleInstance extends TrustedWebActivity {

  protected static final String LOG_TAG = "TrustedWebActivitySingleInstance";

}
