package com.pichillilorenzo.flutter_inappwebview_android.types;

public interface Disposable {
  void dispose();
}
