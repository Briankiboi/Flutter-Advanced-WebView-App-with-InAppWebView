package com.pichillilorenzo.flutter_inappwebview_android_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
