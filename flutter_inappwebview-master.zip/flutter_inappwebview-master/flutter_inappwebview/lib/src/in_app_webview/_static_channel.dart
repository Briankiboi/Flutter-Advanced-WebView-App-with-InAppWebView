import 'package:flutter/services.dart';

const IN_APP_WEBVIEW_STATIC_CHANNEL =
    const MethodChannel('com.pichillilorenzo/flutter_inappwebview_manager');
