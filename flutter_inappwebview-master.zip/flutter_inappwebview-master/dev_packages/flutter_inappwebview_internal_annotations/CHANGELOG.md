## 1.2.0

- Updated `ExchangeableEnum` and `ExchangeableObjectProperty`.

## 1.1.1

- Added `ExchangeableObject.fromMapForceAllInline`.

## 1.1.0

- Added `ExchangeableObject.copyMethod`.

## 1.0.0

Initial release.