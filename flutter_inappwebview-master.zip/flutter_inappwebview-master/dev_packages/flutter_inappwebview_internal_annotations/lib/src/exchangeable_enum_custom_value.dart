class ExchangeableEnumCustomValue {
  const ExchangeableEnumCustomValue();
}
