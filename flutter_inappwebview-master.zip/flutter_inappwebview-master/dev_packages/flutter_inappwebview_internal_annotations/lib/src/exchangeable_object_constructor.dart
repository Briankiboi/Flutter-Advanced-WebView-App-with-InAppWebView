class ExchangeableObjectConstructor {
  const ExchangeableObjectConstructor();
}
