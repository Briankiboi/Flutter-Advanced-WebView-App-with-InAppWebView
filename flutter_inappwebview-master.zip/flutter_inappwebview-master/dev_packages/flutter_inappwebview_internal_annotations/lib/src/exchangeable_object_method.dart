class ExchangeableObjectMethod {
  final bool ignore;
  final bool toMapMergeWith;

  const ExchangeableObjectMethod({
    this.ignore = false,
    this.toMapMergeWith = false
  });
}
